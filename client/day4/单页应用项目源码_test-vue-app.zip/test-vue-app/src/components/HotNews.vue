<template>
  <div>
    <ul class="news-list">
      <li v-for="item in items" :key="item.title">
        {{ item.title }} - {{ item.date }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    items: {
      type: Array,
    },
  },

  // data() {
  //   return {
  //     list: [],
  //   };
  // },
};
</script>

<style scoped>
.news-list {
  list-style: none;
}
</style>