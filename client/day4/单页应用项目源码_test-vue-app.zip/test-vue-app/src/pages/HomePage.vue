<template>
  <div>
    这是主页
    <hot-news :items="newsItems"></hot-news>
  </div>
</template>

<script>
import HotNews from "../components/HotNews.vue";

export default {
  components: {
    HotNews,
  },
  data() {
    return {
      newsItems: [
        { title: "iphone12发售啦", date: new Date() },
        { title: "黑马灵异事件", date: new Date() },
        { title: "特朗普xxxx", date: new Date() },
      ],
    };
  },
};
</script>