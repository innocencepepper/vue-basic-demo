// 使用ES6模块导入语法，导入vue
import Vue from 'vue'
import App from './App.vue'

// 引入VueRouter模块
import VueRouter from 'vue-router'

// 引入页面组件
import HomePage from './pages/HomePage.vue'
import ProductsPage from './pages/ProductsPage.vue'

// 安装VueRouter插件
Vue.use(VueRouter)

// 关闭开发版本的提示信息
Vue.config.productionTip = false

// 创建路由器实例
const router = new VueRouter({
  routes: [
    { name: 'home', path: '/home', component: HomePage },
    { name: 'products', path: '/products', component: ProductsPage }
  ]
})

// 创建Vue实例
const vm = new Vue({
  render: h => h(App),
  router
})

// 挂载Vue实例
vm.$mount('#app')
