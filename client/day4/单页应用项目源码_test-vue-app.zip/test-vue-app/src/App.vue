<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />

    <div>
      <router-link to="/home">主页</router-link> |
      <router-link to="/products">产品</router-link>
    </div>

    <hr>

    <!-- 页面内容显示在这里 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>
